# Required python packages:

1. numpy
2. pandas
3. matplotlib
4. sklearn
5. jupyter
6. pillow
7. pyplot

# Installation

`pip install numpy pandas matplotlib sklearn jupyter pillow pyplot`
